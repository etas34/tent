
<div class="filter_col">

    <h6>Categories</h6>
    <div class="row" id="filter_2">
        <div class="col-md-12 form-group">
            <div class="custom-select-form">
                <select class="wide add_bottom_15 filter-item" id="category">
                    <option value="0" selected>All</option>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>


    <h6>Models</h6>
    <div class="row" id="filter_2">
        <div class="col-md-12 form-group">
            <div class="custom-select-form">
                <select class="wide add_bottom_15 filter-item" id="category">
                    <option value="0" selected>All</option>
                    <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
    <!-- /filter_type -->
    <div class="filter_type version_2">
        <h4><a href="#filter_3" data-toggle="collapse" class="closed">Brands</a></h4>
        <div class="collapse" id="filter_3">
            <ul>
                <li>
                    <label class="container_check">Adidas <small>11</small>
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </li>
                <li>
                    <label class="container_check">Nike <small>08</small>
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </li>
                <li>
                    <label class="container_check">Vans <small>05</small>
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </li>
                <li>
                    <label class="container_check">Puma <small>18</small>
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </li>
            </ul>
        </div>
    </div>
    <!-- /filter_type -->
    <div class="filter_type version_2">
        <h4><a href="#filter_4" data-toggle="collapse" class="closed">Price</a></h4>
        <div class="collapse" id="filter_4">
            <ul>
                <li>
                    <label class="container_check">$0 — $50<small>11</small>
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </li>
                <li>
                    <label class="container_check">$50 — $100<small>08</small>
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </li>
                <li>
                    <label class="container_check">$100 — $150<small>05</small>
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </li>
                <li>
                    <label class="container_check">$150 — $200<small>18</small>
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </li>
            </ul>
        </div>
    </div>
    <!-- /filter_type -->
    <div class="buttons">
        <a href="#0" class="btn_1">Filter</a> <a href="#0" class="btn_1 gray">Reset</a>
    </div>
</div>
<?php /**PATH C:\wamp64\www\tent\resources\views/frontpage/filter.blade.php ENDPATH**/ ?>