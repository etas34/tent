
<?php $__currentLoopData = $width; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <label class="container_check"><?php echo e($value->width); ?> m
            <input type="checkbox" class="cb_width" <?php if(isset($width_id)): ?> checked <?php endif; ?> value="<?php echo e($value->width); ?>">
            <span class="checkmark"></span>
        </label>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\wamp64\www\tent\resources\views/frontpage/widths.blade.php ENDPATH**/ ?>