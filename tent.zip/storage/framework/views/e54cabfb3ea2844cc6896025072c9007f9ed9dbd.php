 <?php if (isset($component)) { $__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminApp::class, []); ?>
<?php $component->withName('admin-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('styles'); ?>


    <?php $__env->stopPush(); ?>


    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Products</h3>
                    <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-primary active" style="float: right !important;">Add New
                        product</a>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>Product Image</th>
                            <th>Product Category</th>
                            <th>Product Model</th>
                            <th>Edit</th>
                            <th>Delete</th>


                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><img src="<?php echo e(asset("storage/images/prds_images/$value->image")); ?>" height="100px" width="100px"></td>
                            <td><?php echo e($value->category->name); ?></td>
                            <td><?php echo e($value->type->name); ?></td>

                            <td><a href="<?php echo e(route('admin.product.edit',$value)); ?>"><span class="badge bg-warning p-2">Edit</span></a></td>
                            <td><a href="<?php echo e(route('admin.product.destroy',$value)); ?>" onclick="return confirm('Are you sure you want to delete this record?')"><span class="badge bg-danger p-2">Delete</span></a></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
    </div>


    <?php $__env->startPush('scripts'); ?>


    <?php $__env->stopPush(); ?>
 <?php if (isset($__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7)): ?>
<?php $component = $__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7; ?>
<?php unset($__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\wamp64\www\tent\resources\views/admin/product/index.blade.php ENDPATH**/ ?>