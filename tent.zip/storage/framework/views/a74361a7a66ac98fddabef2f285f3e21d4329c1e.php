    <!-- Search result will appeared here -->
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-md-4">
            <div class="grid_item">
                
                <figure>
                    <a href="#">
                        <img class="img-fluid lazy" height="400" width="400" src="<?php echo e(asset("storage/images/prds_images/$value->image")); ?>" data-src="<?php echo e(asset("storage/images/prds_images/$value->image")); ?>" alt="">
                    </a>
                </figure>
                <a href="product-detail-1.html">
                    <h3><?php echo e($value->type['name']); ?></h3>
                </a>
                <div class="price_box">
                    <span class="new_price"><?php echo e($value->price); ?>€</span>
                </div>
                <ul>
                    <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left" title="Add to favorites"><i class="ti-heart"></i><span>Add to favorites</span></a></li>
                    <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left" title="Add to compare"><i class="ti-control-shuffle"></i><span>Add to compare</span></a></li>
                    <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left" title="Add to cart"><i class="ti-shopping-cart"></i><span>Add to cart</span></a></li>
                </ul>
            </div>
            <!-- /grid_item -->
        </div>
        <!-- /col -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="pagination__wrapper">
    <?php echo e($product->links("pagination::bootstrap-4")); ?>

</div>
<?php /**PATH C:\wamp64\www\tent\resources\views/frontpage/items.blade.php ENDPATH**/ ?>