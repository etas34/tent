 <?php if (isset($component)) { $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MainLayout::class, []); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>






    <main class="bg_gray">
        <div class="container margin_30">
            <div class="page_header">
                <div class="breadcrumbs">
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Category</a></li>
                        <li><?php echo e($product->type['name']); ?></li>
                    </ul>
                </div>
                <h1><?php echo e($product->type['name']); ?></h1>
            </div>
            <!-- /page_header -->
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="owl-carousel owl-theme prod_pics magnific-gallery">
                        <div class="item">
                            <a href="<?php echo e(asset("storage/images/prds_images/$product->image")); ?>" title="Photo title" data-effect="mfp-zoom-in"><img src="<?php echo e(asset("storage/images/prds_images/$product->image")); ?>" alt=""></a>
                        </div>
                        <!-- /item -->



                        <!-- /item -->
                    </div>
                    <!-- /carousel -->
                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->





























































        <!-- /bg_white -->

        <div class="tabs_product bg_white version_2">
            <div class="container">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a id="tab-A" href="#pane-A" class="nav-link active" data-toggle="tab" role="tab">Description</a>
                    </li>



                </ul>
            </div>
        </div>
        <!-- /tabs_product -->

        <div style="background-color: white !important" class="tab_content_wrapper">
            <div class="container">
                <div class="tab-content" role="tablist">
                    <div id="pane-A" class="card tab-pane fade active show" role="tabpanel" aria-labelledby="tab-A">
                        <div class="card-header" role="tab" id="heading-A">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapse-A" aria-expanded="false" aria-controls="collapse-A">
                                    Description
                                </a>
                            </h5>
                        </div>

                        <div id="collapse-A" class="collapse" role="tabpanel" aria-labelledby="heading-A">
                            <div class="card-body">
                                <div class="row justify-content-between">
                                    <div class="col-lg-6">
                                        <h3>Details</h3>
                                        <?php echo $product->description; ?>

                                    </div>
                                    <div class="col-lg-5">
                                        <h3>Specifications</h3>
                                        <div class="table-responsive">
                                            <table class="table table-sm table-striped">
                                                <tbody>


                                                <tr>
                                                    <td><strong>Price</strong></td>
                                                    <td><?php echo e($product->price); ?> €</td>
                                                </tr>
                                                <td><strong>Width</strong></td>
                                                <td><?php echo e($product->width); ?> m</td>

                                                <tr>
                                                <td><strong>Length</strong></td>
                                                <td><?php echo e($product->length); ?> m</td>
                                                </tr>
                                                <tr>
                                                <td><strong>Price/m²</strong></td>
                                                <td><?php echo e($product->price_m2); ?> €</td>
                                                </tr>
                                                <tr>
                                                <td><strong>Insulation</strong></td>
                                                <td><?php echo e($product->insulation); ?></td>
                                                </tr>
                                                <tr>
                                                <td><strong>Door</strong></td>
                                                <td><?php echo e($product->door); ?> m</td>
                                                </tr>
                                                <tr>
                                                <td><strong>Steep height</strong></td>
                                                <td><?php echo e($product->steep_height); ?> m</td>
                                                </tr>
                                                <tr>
                                                <td><strong>Height middle area</strong></td>
                                                <td><?php echo e($product->height_middle); ?> m</td>
                                                </tr>
                                                <tr>
                                                <td><strong>Square meters</strong></td>
                                                <td><?php echo e($product->square_meters); ?> m²</td>
                                                </tr>
                                                <tr>
                                                <td><strong>Foot height</strong></td>
                                                <td><?php echo e($product->foot_height); ?> m</td>
                                                </tr>
                                                <tr>
                                                <td><strong>Foot count</strong></td>
                                                <td><?php echo e($product->foot_count); ?></td>
                                                </tr>


                                                </tbody>
                                            </table>
                                        </div>
                                        <!-- /table-responsive -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /TAB A -->






























































                    <!-- /tab B -->
                </div>
                <!-- /tab-content -->
            </div>
            <!-- /container -->
        </div>
        <!-- /tab_content_wrapper -->








































































































































        <!-- /bg_white -->

    </main>
    <!-- /main -->


 <?php if (isset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d)): ?>
<?php $component = $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d; ?>
<?php unset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\wamp64\www\tent\resources\views/frontpage/productdetail.blade.php ENDPATH**/ ?>