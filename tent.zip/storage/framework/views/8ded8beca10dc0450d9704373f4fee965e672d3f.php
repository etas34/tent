 <?php if (isset($component)) { $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MainLayout::class, []); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <main>
        <div id="carousel-home">
            <div class="owl-carousel owl-theme">


                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="owl-slide cover"
                         style="background-image: url(<?php echo e(asset("storage/images/slider_images/$value->image")); ?>);">
                        <div class="opacity-mask d-flex align-items-center" data-opacity-mask="rgba(0, 0, 0, 0.5)">
                            <div class="container">
                                <div class="row justify-content-center justify-content-md-end">
                                    <div class="col-lg-6 static">
                                        <div class="slide-text text-right white">
                                            <h2 class="owl-slide-animated owl-slide-title"><?php echo e($value->header); ?></h2>
                                            <p class="owl-slide-animated owl-slide-subtitle">
                                                <?php echo e($value->description); ?>

                                            </p>
                                            <div class="owl-slide-animated owl-slide-cta"><a class="btn_1"
                                                                                             href="listing-grid-1-full.html"
                                                                                             role="button">Shop Now</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>










                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                


            <!--/owl-slide-->
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
            <!--/owl-slide-->
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
            </div>
            <div id="icon_drag_mobile"></div>
        </div>
        <!--/carousel-->

        <ul id="banners_grid" class="clearfix">
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="#0" class="img_container">
                        <img src="<?php echo e(asset('assets/img/banners_cat_placeholder.jpg')); ?>"
                             data-src="<?php echo e(asset("storage/images/cat_images/$value->image")); ?>" alt="" class="lazy">
                        <div class="short_info opacity-mask" data-opacity-mask="rgba(0, 0, 0, 0.5)">
                            <h3><?php echo e($value->name); ?></h3>
                            <div><span class="btn_1">Shop Now</span></div>
                        </div>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <!--/banners_grid -->

        <div class="container margin_60_35">
            <div class="main_title">
                <h2>Custom Products</h2>
                <span>Products</span>
                <p>Cum doctus civibus efficiantur in imperdiet deterruisset</p>
            </div>
            <div class="row small-gutters">
                <div class="col-6 col-md-4 col-xl-3">
                    <div class="grid_item">
                        <figure>
                            <span class="ribbon off">-30%</span>
                            <a href="product-detail-1.html">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/1.jpg')); ?>" alt="">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/1_b.jpg')); ?>" alt="">
                            </a>
                            <div data-countdown="2019/05/15" class="countdown"></div>
                        </figure>
                        <div class="rating"><i class="icon-star voted"></i><i class="icon-star voted"></i><i
                                class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star"></i>
                        </div>
                        <a href="product-detail-1.html">
                            <h3>Armor Air x Fear</h3>
                        </a>
                        <div class="price_box">
                            <span class="new_price">$48.00</span>
                            <span class="old_price">$60.00</span>
                        </div>
                        <ul>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to favorites"><i class="ti-heart"></i><span>Add to favorites</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to compare"><i class="ti-control-shuffle"></i><span>Add to compare</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to cart"><i class="ti-shopping-cart"></i><span>Add to cart</span></a></li>
                        </ul>
                    </div>
                    <!-- /grid_item -->
                </div>
                <!-- /col -->
                <div class="col-6 col-md-4 col-xl-3">
                    <div class="grid_item">
                        <span class="ribbon off">-30%</span>
                        <figure>
                            <a href="product-detail-1.html">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/2.jpg')); ?>" alt="">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/2_b.jpg')); ?>" alt="">
                            </a>
                            <div data-countdown="2019/05/10" class="countdown"></div>
                        </figure>
                        <div class="rating"><i class="icon-star voted"></i><i class="icon-star voted"></i><i
                                class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star"></i>
                        </div>
                        <a href="product-detail-1.html">
                            <h3>Armor Okwahn II</h3>
                        </a>
                        <div class="price_box">
                            <span class="new_price">$90.00</span>
                            <span class="old_price">$170.00</span>
                        </div>
                        <ul>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to favorites"><i class="ti-heart"></i><span>Add to favorites</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to compare"><i class="ti-control-shuffle"></i><span>Add to compare</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to cart"><i class="ti-shopping-cart"></i><span>Add to cart</span></a></li>
                        </ul>
                    </div>
                    <!-- /grid_item -->
                </div>
                <!-- /col -->
                <div class="col-6 col-md-4 col-xl-3">
                    <div class="grid_item">
                        <span class="ribbon off">-50%</span>
                        <figure>
                            <a href="product-detail-1.html">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/3.jpg')); ?>" alt="">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/3_b.jpg')); ?>" alt="">
                            </a>
                            <div data-countdown="2019/05/21" class="countdown"></div>
                        </figure>
                        <div class="rating"><i class="icon-star voted"></i><i class="icon-star voted"></i><i
                                class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star"></i>
                        </div>
                        <a href="product-detail-1.html">
                            <h3>Armor Air Wildwood ACG</h3>
                        </a>
                        <div class="price_box">
                            <span class="new_price">$75.00</span>
                            <span class="old_price">$155.00</span>
                        </div>
                        <ul>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to favorites"><i class="ti-heart"></i><span>Add to favorites</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to compare"><i class="ti-control-shuffle"></i><span>Add to compare</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to cart"><i class="ti-shopping-cart"></i><span>Add to cart</span></a></li>
                        </ul>
                    </div>
                    <!-- /grid_item -->
                </div>
                <!-- /col -->
                <div class="col-6 col-md-4 col-xl-3">
                    <div class="grid_item">
                        <span class="ribbon new">New</span>
                        <figure>
                            <a href="product-detail-1.html">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/4.jpg')); ?>" alt="">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/4_b.jpg')); ?>" alt="">
                            </a>
                        </figure>
                        <div class="rating"><i class="icon-star voted"></i><i class="icon-star voted"></i><i
                                class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star"></i>
                        </div>
                        <a href="product-detail-1.html">
                            <h3>Armor ACG React Terra</h3>
                        </a>
                        <div class="price_box">
                            <span class="new_price">$110.00</span>
                        </div>
                        <ul>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to favorites"><i class="ti-heart"></i><span>Add to favorites</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to compare"><i class="ti-control-shuffle"></i><span>Add to compare</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to cart"><i class="ti-shopping-cart"></i><span>Add to cart</span></a></li>
                        </ul>
                    </div>
                    <!-- /grid_item -->
                </div>
                <!-- /col -->
                <div class="col-6 col-md-4 col-xl-3">
                    <div class="grid_item">
                        <span class="ribbon new">New</span>
                        <figure>
                            <a href="product-detail-1.html">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/5.jpg')); ?>" alt="">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/5_b.jpg')); ?>" alt="">
                            </a>
                        </figure>
                        <div class="rating"><i class="icon-star voted"></i><i class="icon-star voted"></i><i
                                class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star"></i>
                        </div>
                        <a href="product-detail-1.html">
                            <h3>Armor Air Zoom Alpha</h3>
                        </a>
                        <div class="price_box">
                            <span class="new_price">$140.00</span>
                        </div>
                        <ul>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to favorites"><i class="ti-heart"></i><span>Add to favorites</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to compare"><i class="ti-control-shuffle"></i><span>Add to compare</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to cart"><i class="ti-shopping-cart"></i><span>Add to cart</span></a></li>
                        </ul>
                    </div>
                    <!-- /grid_item -->
                </div>
                <!-- /col -->
                <div class="col-6 col-md-4 col-xl-3">
                    <div class="grid_item">
                        <span class="ribbon new">New</span>
                        <figure>
                            <a href="product-detail-1.html">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/6.jpg')); ?>" alt="">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/6_b.jpg')); ?>" alt="">
                            </a>
                        </figure>
                        <div class="rating"><i class="icon-star voted"></i><i class="icon-star voted"></i><i
                                class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star"></i>
                        </div>
                        <a href="product-detail-1.html">
                            <h3>Armor Air Alpha</h3>
                        </a>
                        <div class="price_box">
                            <span class="new_price">$130.00</span>
                        </div>
                        <ul>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to favorites"><i class="ti-heart"></i><span>Add to favorites</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to compare"><i class="ti-control-shuffle"></i><span>Add to compare</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to cart"><i class="ti-shopping-cart"></i><span>Add to cart</span></a></li>
                        </ul>
                    </div>
                    <!-- /grid_item -->
                </div>
                <!-- /col -->
                <div class="col-6 col-md-4 col-xl-3">
                    <div class="grid_item">
                        <span class="ribbon hot">Hot</span>
                        <figure>
                            <a href="product-detail-1.html">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/7.jpg')); ?>" alt="">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/7_b.jpg')); ?>" alt="">
                            </a>
                        </figure>
                        <div class="rating"><i class="icon-star voted"></i><i class="icon-star voted"></i><i
                                class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star"></i>
                        </div>
                        <a href="product-detail-1.html">
                            <h3>Armor Air Max 98</h3>
                        </a>
                        <div class="price_box">
                            <span class="new_price">$115.00</span>
                        </div>
                        <ul>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to favorites"><i class="ti-heart"></i><span>Add to favorites</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to compare"><i class="ti-control-shuffle"></i><span>Add to compare</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to cart"><i class="ti-shopping-cart"></i><span>Add to cart</span></a></li>
                        </ul>
                    </div>
                    <!-- /grid_item -->
                </div>
                <!-- /col -->
                <div class="col-6 col-md-4 col-xl-3">
                    <div class="grid_item">
                        <span class="ribbon hot">Hot</span>
                        <figure>
                            <a href="product-detail-1.html">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/8.jpg')); ?>" alt="">
                                <img class="img-fluid lazy"
                                     src="<?php echo e(asset('assets/img/products/product_placeholder_square_medium.jpg')); ?>"
                                     data-src="<?php echo e(asset('assets/img/products/shoes/8_b.jpg')); ?>" alt="">
                            </a>
                        </figure>
                        <div class="rating"><i class="icon-star voted"></i><i class="icon-star voted"></i><i
                                class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star"></i>
                        </div>
                        <a href="product-detail-1.html">
                            <h3>Armor Air Max 720</h3>
                        </a>
                        <div class="price_box">
                            <span class="new_price">$120.00</span>
                        </div>
                        <ul>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to favorites"><i class="ti-heart"></i><span>Add to favorites</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to compare"><i class="ti-control-shuffle"></i><span>Add to compare</span></a>
                            </li>
                            <li><a href="#0" class="tooltip-1" data-toggle="tooltip" data-placement="left"
                                   title="Add to cart"><i class="ti-shopping-cart"></i><span>Add to cart</span></a></li>
                        </ul>
                    </div>
                    <!-- /grid_item -->
                </div>
                <!-- /col -->
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- /featured -->


    </main>
    <?php $__env->startPush('scripts'); ?>

        <script src="<?php echo e(asset('assets/js/carousel-home.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.cookiebar.js')); ?>"></script>

        <script>
            $(document).ready(function () {
                // 'use strict';
                $.cookieBar({
                    fixed: true
                });
            });
        </script>

    <?php $__env->stopPush(); ?>
 <?php if (isset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d)): ?>
<?php $component = $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d; ?>
<?php unset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\wamp64\www\tent\resources\views/index.blade.php ENDPATH**/ ?>