 <?php if (isset($component)) { $__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminApp::class, []); ?>
<?php $component->withName('admin-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php $__env->startPush('styles'); ?>


<?php $__env->stopPush(); ?>


    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Insulations</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <form action="<?php echo e(route('admin.insulation.store')); ?>" method="post" autocomplete="off"  enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="card-body">





                        <div class="row">
                            <div class="col-12">
                                <!-- Custom Tabs -->
                                <div class="card">
                                    <div class="card-header d-flex p-0">
                                        <h3 class="card-title p-3">Translate</h3>
                                        <ul class="nav nav-pills ml-auto p-2">
                                            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="nav-item"><a class="nav-link <?php if($key == 'de'): ?> active <?php endif; ?>" href="#<?php echo e($key); ?>" data-toggle="tab"><?php echo e($value); ?></a></li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </div><!-- /.card-header -->
                                    <div class="card-body">
                                        <div class="tab-content">
                                            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="tab-pane <?php if($key == 'de'): ?> active <?php endif; ?>" id="<?php echo e($key); ?>">
                                                    <div class="form-group">

                                                        <label for="mod_name">insulation Name (<?php echo e($value); ?>)</label>
                                                        <input type="text" name="ins_name[<?php echo e($key); ?>]"  class="form-control" id="mod_name" placeholder="Enter insulation Name">
                                                    </div>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                        <!-- /.tab-content -->
                                    </div><!-- /.card-body -->

                                </div>
                                <!-- ./card -->
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->


                    </div>
                    <!-- /.card-body -->

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary float-right">Kaydet</button>
                    </div>
                </form>
            </div>
            <!-- /.card -->

        </div>
    </div>






<?php $__env->startPush('scripts'); ?>
        <script>

        </script>

<?php $__env->stopPush(); ?>
 <?php if (isset($__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7)): ?>
<?php $component = $__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7; ?>
<?php unset($__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\wamp64\www\tent\resources\views/admin/insulation/create.blade.php ENDPATH**/ ?>