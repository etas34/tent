
<?php $__currentLoopData = $door; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <label class="container_check"><?php echo e($value->door); ?> m
            <input type="checkbox" class="cb_door" <?php if(isset($door_id)): ?> checked <?php endif; ?> value="<?php echo e($value->door); ?>">
            <span class="checkmark"></span>
        </label>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\wamp64\www\tent\resources\views/frontpage/doors.blade.php ENDPATH**/ ?>