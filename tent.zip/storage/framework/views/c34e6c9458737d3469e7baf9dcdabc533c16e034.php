
<div class="custom-select-form">
    <select class="wide add_bottom_15 filter-item" id="modelselectbox">
        <option value="0" selected>All</option>
        <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value->id); ?>" <?php if(isset($model_id) && $model_id==$value->id): ?> selected <?php endif; ?>><?php echo e($value->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<?php /**PATH C:\wamp64\www\tent\resources\views/frontpage/models.blade.php ENDPATH**/ ?>